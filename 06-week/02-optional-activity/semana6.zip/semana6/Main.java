public class Main {
    public static void main(String[] args) {

        // Crear un objeto Docente
        Docente docente1 = new Docente(
            "Laura Martínez",
            35,
            "laura.martinez@corhuila.edu.co",
            "Programación Orientada a Objetos",
            "Magíster en Ingeniería de Software"
        );

        // Crear un objeto Administrativo
        Administrativo admin1 = new Administrativo(
            "Carlos Pérez",
            42,
            "carlos.perez@corhuila.edu.co",
            "Jefe de Registro y Control",
            "Secretaría Académica"
        );

        // Imprimir fichas en consola
        docente1.mostrarFicha();
        admin1.mostrarFicha();
    }
}