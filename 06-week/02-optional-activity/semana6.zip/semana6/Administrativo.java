public class Administrativo extends Persona {
    // Atributos específicos del administrativo
    private final String cargo;
    private final String dependencia;

    public Administrativo(String nombre, int edad, String correo,
                          String cargo, String dependencia) {
        // Inicializa los atributos heredados de Persona
        super(nombre, edad, correo);
        this.cargo = cargo;
        this.dependencia = dependencia;
    }

    @Override
    public void mostrarFicha() {
        super.mostrarFicha();   // reutiliza la ficha base
        System.out.println("Rol         : Administrativo");
        System.out.println("Cargo       : " + cargo);
        System.out.println("Dependencia : " + dependencia);
        System.out.println("----------------------");
    }
}