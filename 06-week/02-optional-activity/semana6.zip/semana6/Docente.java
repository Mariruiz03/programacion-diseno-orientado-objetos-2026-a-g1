public class Docente extends Persona {
    // Atributos específicos del docente
    private final String asignatura;
    private final String titulo;

    public Docente(String nombre, int edad, String correo,
                   String asignatura, String titulo) {
        // Inicializa los atributos heredados de Persona
        super(nombre, edad, correo);
        this.asignatura = asignatura;
        this.titulo = titulo;
    }

    @Override
    public void mostrarFicha() {
        super.mostrarFicha();   // reutiliza la ficha base
        System.out.println("Rol        : Docente");
        System.out.println("Asignatura : " + asignatura);
        System.out.println("Título     : " + titulo);
        System.out.println("----------------------");
    }
}
