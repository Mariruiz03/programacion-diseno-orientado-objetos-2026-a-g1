public class Persona {
    // Atributos comunes a todo el personal universitario
    protected String nombre;
    protected int edad;
    protected String correo;

    // Constructor base
    public Persona(String nombre, int edad, String correo) {
        this.nombre = nombre;
        this.edad = edad;
        this.correo = correo;
    }

    // Método para mostrar la ficha básica
    public void mostrarFicha() {
        System.out.println("=== FICHA PERSONAL ===");
        System.out.println("Nombre : " + nombre);
        System.out.println("Edad   : " + edad + " años");
        System.out.println("Correo : " + correo);
    }
}