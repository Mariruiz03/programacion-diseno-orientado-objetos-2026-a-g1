public class Envio {
    // Atributos comunes a todo tipo de envío
    protected String destinatario;
    protected double peso;      // en kg
    protected String destino;

    public Envio(String destinatario, double peso, String destino) {
        this.destinatario = destinatario;
        this.peso = peso;
        this.destino = destino;
    }

    // Método que cada subclase sobreescribirá con su lógica propia
    public double calcularCosto() {
        return 0.0;
    }

    public void mostrarResumen() {
        System.out.println("Destinatario : " + destinatario);
        System.out.println("Destino      : " + destino);
        System.out.println("Peso         : " + peso + " kg");
        System.out.printf( "Costo        : $%.2f%n", calcularCosto());
        System.out.println("------------------------------");
    }
}