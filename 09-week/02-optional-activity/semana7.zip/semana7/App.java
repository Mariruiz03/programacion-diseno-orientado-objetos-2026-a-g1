import java.util.ArrayList;
import java.util.List;

public class App {
    public static void main(String[] args) {

        // Lista polimórfica: todos son tratados como Envio
        List<Envio> envios = new ArrayList<>();

        envios.add(new EnvioEstandar("Ana Torres", 3.0, "Bogotá"));
        envios.add(new EnvioExpress("Luis García", 1.5, "Medellín"));
        envios.add(new EnvioInternacional("María López", 2.0, "Miami - EE.UU.", 0.15));
        envios.add(new EnvioEstandar("Pedro Ruiz", 5.0, "Cali"));
        envios.add(new EnvioExpress("Sofía Nieto", 0.8, "Barranquilla"));

        double totalGeneral = 0;

        // Polimorfismo en acción: cada objeto ejecuta SU propio calcularCosto()
        for (Envio e : envios) {
            e.mostrarResumen();
            totalGeneral += e.calcularCosto();
        }

        System.out.printf("💰 COSTO TOTAL DE TODOS LOS ENVÍOS: $%.2f%n", totalGeneral);
    }
}