public class EnvioInternacional extends Envio {

    private final double tasaAduanas;   // porcentaje extra por aduanas (ej: 0.15 = 15%)

    public EnvioInternacional(String destinatario, double peso,
                               String destino, double tasaAduanas) {
        super(destinatario, peso, destino);
        this.tasaAduanas = tasaAduanas;
    }

    // Tarifa internacional: $30.000 base + $8.000/kg + recargo de aduanas
    @Override
    public double calcularCosto() {
        double base = 30000 + (peso * 8000);
        return base + (base * tasaAduanas);
    }

    @Override
    public void mostrarResumen() {
        System.out.println("=== ENVÍO INTERNACIONAL ===");
        System.out.println("Tasa aduanas : " + (tasaAduanas * 100) + "%");
        super.mostrarResumen();
    }
}