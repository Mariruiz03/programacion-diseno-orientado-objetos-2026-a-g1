public class EnvioExpress extends Envio {

    public EnvioExpress(String destinatario, double peso, String destino) {
        super(destinatario, peso, destino);
    }

    // Tarifa express: $12.000 base + $5.000 por kg (entrega rápida)
    @Override
    public double calcularCosto() {
        return 12000 + (peso * 5000);
    }

    @Override
    public void mostrarResumen() {
        System.out.println("=== ENVÍO EXPRESS ===");
        super.mostrarResumen();
    }
}