public class EnvioEstandar extends Envio {

    public EnvioEstandar(String destinatario, double peso, String destino) {
        super(destinatario, peso, destino);
    }

    // Tarifa estándar: $5.000 base + $2.000 por kg
    @Override
    public double calcularCosto() {
        return 5000 + (peso * 2000);
    }

    @Override
    public void mostrarResumen() {
        System.out.println("=== ENVÍO ESTÁNDAR ===");
        super.mostrarResumen();
    }
}